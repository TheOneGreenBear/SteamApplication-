package com.greenhill.scott.steamApplication;

import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.greenhill.scott.steamApplication.Adapter.FriendsAdapter;
import com.greenhill.scott.steamApplication.LitePalDatabase.Friend;
import com.greenhill.scott.steamApplication.Utilities.HTTPOk3;
import com.greenhill.scott.steamApplication.Utilities.Navigation;
import com.greenhill.scott.steamApplication.Utilities.Responses;

import org.litepal.crud.DataSupport;

import java.io.IOException;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class FriendsActivity extends AppCompatActivity {

    private FriendsAdapter friendsAdapter;
    private List<Friend> friendList;

    private ListView friend_list_view;
    private NavigationView navigationView;
    private DrawerLayout friends_drawerLayout;
    private TextView titletext;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.friend_list);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //set navigation menu
        friends_drawerLayout = findViewById(R.id.friend_drawer_layout);
        //set navigation button
        getSupportActionBar().setTitle("Friends");

        //load navi bar
        navigationView = findViewById(R.id.nav_view);
        Navigation.initiNavView(navigationView, this, friends_drawerLayout);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                friends_drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        friend_list_view = findViewById(R.id.friend_listview);

        Friends();
    }

    private void Friends(){
        friendList = DataSupport.findAll(Friend.class);


        if(friendList.size() == 0 || friendList.get(0).getFriendinfo() == null){
            String address = "http://api.steampowered.com/ISteamUser/GetFriendList/v0001/?key=" + GameList.PERSONAL_KEY
                    + "&steamid=" + GameList.STEAM_ID + "&relationship=friend";
            getFriendsInfoFromAPI(address);

        }else{

            Log.d("friends size", String.valueOf(friendList.size()));
            friendsAdapter = new FriendsAdapter(FriendsActivity.this, R.layout.friend_item, friendList);
            friend_list_view.setAdapter(friendsAdapter);
            friend_list_view.setSelection(0);
        }
    }

    private void getFriendsInfoFromAPI(String address){
        HTTPOk3.sendOkHttpRequest(address, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Toast.makeText(FriendsActivity.this,"Failed to load friends list",Toast.LENGTH_SHORT);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseText = response.body().string();
                boolean result = Responses.userFriendListResponse(responseText);



                if(result){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.d("query:", " friends summary");
                            getFriendssummeryFromAPI();
                        }
                    });
                }
            }
        });
    }


    /**
     * query friends summaries from server
     */
    private void getFriendssummeryFromAPI(){

        friendList = DataSupport.findAll(Friend.class);

        //get address
        StringBuilder friendsSummary = new StringBuilder( "http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key="
                + GameList.PERSONAL_KEY
                + "&steamids=");

        for(int i = 0; i < friendList.size()-1; i++){
            friendsSummary.append(friendList.get(i).getFriendsteamid() + "||steamids=");
        }
        friendsSummary.append(friendList.get(friendList.size()-1).getFriendsteamid());
        friendsSummary.append("&relationship=friend");

        Log.d("friends summaries", friendsSummary.toString());
        HTTPOk3.sendOkHttpRequest(friendsSummary.toString(), new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(FriendsActivity.this, "Failed to get friends summary", Toast.LENGTH_SHORT).show();

                    }
                });

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseText = response.body().string();
                boolean result = Responses.userInfo(responseText);
                if(result){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Friends();
                        }
                    });
                }

            }
        });

    }
}
