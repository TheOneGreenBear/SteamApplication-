package com.greenhill.scott.steamApplication.Utilities;

import android.text.TextUtils;

import com.greenhill.scott.steamApplication.LitePalDatabase.Achievements;
import com.greenhill.scott.steamApplication.LitePalDatabase.Friend;
import com.greenhill.scott.steamApplication.LitePalDatabase.Game;
import com.greenhill.scott.steamApplication.LitePalDatabase.UserInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class Responses {

    //all the calls made to the steam API server


    //retrieves the users game's including name, playtime, the appid (the unique ID for that game) and the image
    public static boolean userGameListResponse(String response) {

        if (!TextUtils.isEmpty(response)) {
            try {
                JSONObject content = new JSONObject(response);

                JSONArray allGames = content.getJSONObject("response").getJSONArray("games");

                for (int i = 0; i < allGames.length(); i++) {
                    JSONObject gameObject = allGames.getJSONObject(i);
                    Game game = new Game();
                    game.setAppid(gameObject.getInt("appid"));
                    game.setGameName(gameObject.getString("name"));
                    game.setPlayTime(gameObject.getDouble("playtime_forever"));
                    game.setIconhash(gameObject.getString("img_icon_url"));

                    game.saveOrUpdate("appid = ?", String.valueOf(game.getAppid())); //add to database. If already exists - update if not add
                }

                return true;

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    //get all the users friends
    public static boolean userFriendListResponse(String response) {
        try {
            JSONObject content = new JSONObject(response);
            JSONArray allfriends = content.getJSONObject("friendslist").getJSONArray("friends");

            for (int i = 0; i < allfriends.length(); i++) {
                JSONObject friendObject = allfriends.getJSONObject(i);
                Friend friend = new Friend();
                friend.setFriendsteamid(friendObject.getString("steamid"));
                friend.setFriendsince(friendObject.getString("friend_since"));

                friend.saveOrUpdate("friendsteamid = ?", String.valueOf(friend.getFriendsteamid())); //add to database. If already exists - update if not add

            }
            return true;
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return false;
    }


    //gets all the users games achievements
    public static boolean userGameAchievements(Game game, String response) {
        try {

            JSONObject content = new JSONObject(response);
            //this game doesn't have achievements
            if (!content.getJSONObject("playerstats").getBoolean("success")) return false;

            JSONArray all_achievements = content.getJSONObject("playerstats").getJSONArray("achievements");

            for (int i = 0; i < all_achievements.length(); i++) {
                JSONObject achievementObject = all_achievements.getJSONObject(i);
                Achievements achievements = new Achievements();

                achievements.setAchieved(achievementObject.getInt("achieved"));
                achievements.setAchievementName(achievementObject.getString("name"));
                achievements.setDescription(achievementObject.getString("description"));
                achievements.setUnlocktime(achievementObject.getString("unlocktime"));
                game.setAchievements(achievements);

                //update based on name
                achievements.saveOrUpdate("achievementName=?", achievements.getAchievementName());
            }
            //create relation: one game to multiple achievements
            game.save();

            return true;

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return false;
    }


    //gets all the users information
    public static boolean userInfo(String response) {
        try {
            JSONObject content = new JSONObject(response);
            JSONArray my_profile = content.getJSONObject("response").getJSONArray("players");

            for (int i = 0; i < my_profile.length(); i++) {
                JSONObject userObeject = my_profile.getJSONObject(i);
                UserInfo userInfo = new UserInfo();
                userInfo.setPersonaname(userObeject.getString("personaname"));
                userInfo.setSteamid(userObeject.getString("steamid"));
                userInfo.setLastlogofftime(userObeject.optString("lastlogoff"));
                userInfo.setProfileurl(userObeject.getString("profileurl"));
                userInfo.setAvatarurl(userObeject.optString("avatarfull"));
                userInfo.setRealname(userObeject.optString("realname"));
                //userInfo.setTimecreated(userObeject.getString("timecreated")); //not working keeps giving error.
                userInfo.setLoccountrycode(userObeject.optString("loccountrycode"));
                userInfo.setLocstatecode(userObeject.optString("locstatecode"));
                userInfo.setLoccityid(userObeject.optString("loccityid"));

                userInfo.saveOrUpdate("steamid=?", userInfo.getSteamid());
            }
            return true;

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return false;
    }

}
