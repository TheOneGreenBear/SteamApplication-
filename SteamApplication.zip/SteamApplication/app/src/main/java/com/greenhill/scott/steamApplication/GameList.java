package com.greenhill.scott.steamApplication;

import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.greenhill.scott.steamApplication.Adapter.GameAdapter;
import com.greenhill.scott.steamApplication.LitePalDatabase.Game;
import com.greenhill.scott.steamApplication.LitePalDatabase.UserInfo;
import com.greenhill.scott.steamApplication.Utilities.HTTPOk3;
import com.greenhill.scott.steamApplication.Utilities.Responses;

import org.litepal.crud.DataSupport;

import java.io.IOException;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;


public class GameList extends Fragment {

    public static final String PERSONAL_KEY= "B3E3B6D8121A4CD4437F92C2BD098ECC";

    public static String STEAM_ID ="76561198046643785";

    private ProgressDialog progressDialog;

    private ListView listView;

    private List<Game> gamelist;

    private GameAdapter gameAdapter;
    
    

    private Game selectedGame;

    //userinfo object
    private UserInfo mySteam;

    private View view;
    private ProgressBar progressBar;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.game_list,container,false);
        listView = view.findViewById(R.id.game_listview);
        final EditText steamID = view.findViewById(R.id.edtSteamID);
        Button steamIdSubmit = view.findViewById(R.id.steamIDSumbmit);
        progressBar =  view.findViewById(R.id.progressbar);
        progressBar.setVisibility(View.INVISIBLE);

        steamIdSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(steamID.toString())){
                    steamID.setError("Can not be empty");
                }else {
                    STEAM_ID = steamID.getText().toString();
                    DataSupport.deleteAll(Game.class);
                    DataSupport.deleteAll(UserInfo.class);
                    getUserInfo();
                    getGames();
                    steamID.getText().clear();
                }
            }
        });
        return view;

    }

    @Override
    public void onActivityCreated(final Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedGame = gamelist.get(position);
                Intent intent = new Intent(getActivity(), AchievementsActivity.class);
                intent.putExtra("SelectedGame", selectedGame);
                startActivity(intent);

            }
        });
        getUserInfo();
        getGames();
    }

    public void Title(){

        ImageView avatar = view.findViewById(R.id.user_avatar);
        TextView personal_name = view.findViewById(R.id.personal_name);
        TextView real_name =  view.findViewById(R.id.real_name);
        TextView time_created =  view.findViewById(R.id.time_created);
        TextView last_logoff =  view.findViewById(R.id.last_logoff);
        TextView location =  view.findViewById(R.id.location);
        Button profile_url =  view.findViewById(R.id.profile_url);
        Glide.with(this).load(mySteam.getAvatarurl()).into(avatar);
        personal_name.setText(mySteam.getPersonaname());
        last_logoff.setText("Last Log off Time: " + mySteam.getLastlogofftime());
        location.setText("Location: " + mySteam.getLoccityid() + " " + mySteam.getLocstatecode() + " " + mySteam.getLoccountrycode());
        profile_url.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), ProfileViewActivity.class).putExtra("profile_url", mySteam.getProfileurl()));
            }
        });

    }

    private void getGames(){

        gamelist = DataSupport.findAll(Game.class);

        if(gamelist.size() == 0){
            String address = "http://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/?key=" + PERSONAL_KEY +
                    "&include_appinfo=1&steamid=" + STEAM_ID + "&format=json";
            getGameFromAPI(address);
        }

        gameAdapter = new GameAdapter(getContext(), R.layout.game_item, gamelist);
        listView.setAdapter(gameAdapter);
        listView.setSelection(0);
    }
    //private void gameDetail()

    private void getGameFromAPI(String address){

        progressBar.setVisibility(View.VISIBLE);

        HTTPOk3.sendOkHttpRequest(address, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseText = response.body().string();
                boolean result = false;

                result = Responses.userGameListResponse(responseText);
                if(result){
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setVisibility(View.INVISIBLE);
                            getGames();
                        }
                    });
                }
                progressBar.setVisibility(View.INVISIBLE);
            }
        });
    }

    /**
     * query user steam info
     */
    private void getUserInfo(){
        List<UserInfo> tmplist = DataSupport.where("steamid = ?", STEAM_ID).find(UserInfo.class);

        if(tmplist.size() == 0){
            String address = "http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=" +
                    PERSONAL_KEY + "&steamids=" + STEAM_ID;
            getInfoFromAPI(address);
        }else{
            mySteam = tmplist.get(0);
            Title();
        }
    }

    private void getInfoFromAPI(String address){
        HTTPOk3.sendOkHttpRequest(address, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //Toast.makeText(getContext(), "Loading of user data failed", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseText = response.body().string();
                boolean result = Responses.userInfo(responseText);
                if(result){
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            getUserInfo();
                        }
                    });

                }
            }
        });

    }





}
