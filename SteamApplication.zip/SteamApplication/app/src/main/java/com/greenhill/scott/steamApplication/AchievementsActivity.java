package com.greenhill.scott.steamApplication;


import android.app.ProgressDialog;
import android.os.Bundle;

import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.greenhill.scott.steamApplication.Adapter.AchievementsAdapter;
import com.greenhill.scott.steamApplication.LitePalDatabase.Achievements;
import com.greenhill.scott.steamApplication.LitePalDatabase.Game;
import com.greenhill.scott.steamApplication.Utilities.HTTPOk3;
import com.greenhill.scott.steamApplication.Utilities.Responses;

import java.io.IOException;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

import static org.litepal.LitePalApplication.getContext;


public class AchievementsActivity extends AppCompatActivity {

    private TextView gameName;
    private TextView achievementProgress;
    private ImageView gameIconAch;

    private ProgressDialog ach_progressDialog;


    private TextView titleText;

    private ListView achlistView;
    private List<Achievements> achievementsList;
    private AchievementsAdapter achievementsAdapters;

    private Game selectedGame;


    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.achievement_list);

        achlistView = findViewById(R.id.achievement_listview);

        //gets the selected game
        selectedGame = (Game) getIntent().getSerializableExtra("SelectedGame");
        achievementGetter(selectedGame);

    }

    private void initTitle() {


        gameName = findViewById(R.id.game_name_ach);
        achievementProgress = findViewById(R.id.achievements_progress);
        gameIconAch = findViewById(R.id.game_icon_ach);
        titleText = findViewById(R.id.ach_title_text);

        titleText.setText("Achievements");
        gameName.setText(selectedGame.getGameName());

        //gets the games image
        achievementProgress.setText(achievementProgress.getText() + String.valueOf(selectedGame.getAcquiredAch()) + "/" + achievementsList.size());
        String address = "http://cdn.akamai.steamstatic.com/steam/apps/" + selectedGame.getAppid() +
                "/header.jpg";
        Glide.with(this).load(address).placeholder(R.drawable.placeholder).crossFade().into(gameIconAch);

    }


    private void achievementGetter(Game game) {

        achievementsList = game.getAchievements();

        if (achievementsList.size() == 0) {
            String address = "http://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v0001/?appid=" + game.getAppid() +
                    "&key=" + GameList.PERSONAL_KEY + "&steamid=" + GameList.STEAM_ID + "&l=en";
            getAchievementsFromAPI(game, address);
        } else {
            achievementsList = selectedGame.getAchievements();
            achievementsAdapters = new AchievementsAdapter(AchievementsActivity.this, R.layout.achievement_item, achievementsList);
            achlistView.setAdapter(achievementsAdapters);
            achlistView.setSelection(0);
            initTitle();
        }


    }

    private void getAchievementsFromAPI(final Game game, String address) {
        // MainActivity.showProgressDialog(this,ach_progressDialog);

        HTTPOk3.sendOkHttpRequest(address, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //Toast.makeText(getContext(), "This game doesn't have any achievements unlock", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseText = response.body().string();
                boolean result;
                result = Responses.userGameAchievements(game, responseText);

                if (result) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            achievementGetter(game);
                        }
                    });
                }

            }
        });
    }

}
