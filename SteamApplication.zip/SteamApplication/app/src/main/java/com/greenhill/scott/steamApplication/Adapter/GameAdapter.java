package com.greenhill.scott.steamApplication.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.greenhill.scott.steamApplication.R;
import com.greenhill.scott.steamApplication.LitePalDatabase.Game;

import java.util.List;

public class GameAdapter extends ArrayAdapter {
    private int resourceID;
    // private SharedPreferences sharedPreferences;

    public GameAdapter(Context context, int textViewResourceId, List<Game> objects) {
        super(context, textViewResourceId, objects);
        //  sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        resourceID = textViewResourceId;

    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Game game = (Game) getItem(position);
        View view;
        if (convertView == null) {
            view = LayoutInflater.from(getContext()).inflate(resourceID, parent, false);
        } else {
            view = convertView;
        }

        //wire in
        ImageView game_icon_view = view.findViewById(R.id.game_icon);
        TextView achievementName = view.findViewById(R.id.game_name);
        TextView achievementUnlockTime = view.findViewById(R.id.play_time);


//fetches the games header image and uses the games ID from the db to apply it to game_icon_view
        String address = "http://cdn.akamai.steamstatic.com/steam/apps/" + game.getAppid() +
                "/header.jpg";

        //adds placeholder and fade animation.
        Glide.with(getContext()).load(address).placeholder(R.drawable.placeholder).crossFade().into(game_icon_view);

        achievementName.setText(game.getGameName());

        achievementUnlockTime.setText("Play Time: " + game.getPlayTime() + " hours");

        return view;
    }


}

