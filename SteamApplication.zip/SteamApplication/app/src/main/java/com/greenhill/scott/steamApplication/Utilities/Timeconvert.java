package com.greenhill.scott.steamApplication.Utilities;


import java.text.SimpleDateFormat;
import java.util.Date;


//steam API time is in hours. this code makes it so it's in days months and years
public class Timeconvert {

    public static String converTime(String unixtime) {
        if (unixtime.equals("")) return "";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        Date date = new Date(Long.valueOf(unixtime) * 1000);

        return simpleDateFormat.format(date);
    }
}
