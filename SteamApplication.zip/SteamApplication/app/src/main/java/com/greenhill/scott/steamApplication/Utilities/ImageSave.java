package com.greenhill.scott.steamApplication.Utilities;

import android.content.SharedPreferences;

import com.greenhill.scott.steamApplication.LitePalDatabase.Game;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

//loads an image from API and saves it to shared.
public class ImageSave {

    public static void loadPic(String address, final SharedPreferences sharedPreferences, final Game game) {

        HTTPOk3.sendOkHttpRequest(address, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String image = response.body().string();
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(game.getGameName(), image);
                editor.apply();
            }
        });

    }
}
