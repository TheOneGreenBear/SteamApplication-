package com.greenhill.scott.steamApplication;

import android.app.ProgressDialog;
import android.content.Context;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.greenhill.scott.steamApplication.Utilities.Navigation;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //set navigation menu
        drawerLayout = findViewById(R.id.drawer_layout);
        //set navigation button
        //toolbar.setNavigationIcon(R.drawable.castlecrahsers);
        getSupportActionBar().setTitle("Owned Games");

        navigationView = findViewById(R.id.nav_view);
        Navigation.initiNavView(navigationView, this, drawerLayout);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
    }


    public static void showProgressDialog(Context context, ProgressDialog progressDialog){
        if(progressDialog == null){
            progressDialog = new ProgressDialog(context);
            progressDialog.setCancelable(false);
        }
        progressDialog.show();
    }

    public static void closeProgressDialog(ProgressDialog progressDialog){
        if(progressDialog != null) progressDialog.dismiss();
    }
}
