package com.greenhill.scott.steamApplication.Utilities;

import android.app.Activity;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.view.MenuItem;

import com.greenhill.scott.steamApplication.FriendsActivity;
import com.greenhill.scott.steamApplication.MainActivity;
import com.greenhill.scott.steamApplication.R;
import com.greenhill.scott.steamApplication.LitePalDatabase.Achievements;
import com.greenhill.scott.steamApplication.LitePalDatabase.Friend;
import com.greenhill.scott.steamApplication.LitePalDatabase.Game;
import com.greenhill.scott.steamApplication.LitePalDatabase.UserInfo;

import org.litepal.crud.DataSupport;


public class Navigation {

    public static void initiNavView(NavigationView navigationView, final Activity activity, final DrawerLayout drawerLayout){

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemid = item.getItemId();
                switch (itemid){
                    case (R.id.nav_friendslist):
                        item.setChecked(true);
                        Intent friendAc_intent = new Intent(activity, FriendsActivity.class);
                        activity.startActivity(friendAc_intent);
                        drawerLayout.closeDrawers();
                        break;
                    case (R.id.nav_gamelist):
                        item.setChecked(true);
                        Intent gameAc_intent = new Intent(activity, MainActivity.class);
                        activity.startActivity(gameAc_intent);
                        drawerLayout.closeDrawers();
                        break;
                    case (R.id.nav_deleteall):
                        item.setChecked(true);
                        DataSupport.deleteAll(Game.class);
                        DataSupport.deleteAll(Friend.class);
                        DataSupport.deleteAll(Achievements.class);
                        DataSupport.deleteAll(UserInfo.class);
                        break;
                    default:

                }
                return true;
            }
        });
    }
}